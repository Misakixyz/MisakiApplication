package com.misaki.pom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PomApplication {

	public static void main(String[] args) {
		SpringApplication.run(PomApplication.class, args);
	}

}
