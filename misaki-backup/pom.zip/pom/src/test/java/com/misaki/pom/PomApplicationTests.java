package com.misaki.pom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PomApplicationTests {

	@Test
	void contextLoads() {
	}

}
